# Point Cloud Cruise

**Fly through massive point clouds with game-style WASD controls.**

Point Cloud Cruise is a native C++ point cloud viewer for macOS, Windows, and
Linux. It streams out-of-core
octrees from disk, so you can open clouds far larger than your RAM, and fly
through them like a game level — right-mouse look, WASD + QE movement, just
like the Unreal Engine editor.

[日本語 README はこちら](README.ja.md)

![screenshot](docs/screenshot.png)

## Features

- **Game-style navigation** — hold RMB to look around, WASD to move, Q/E for
  down/up, Shift to sprint, scroll wheel to change speed. If you've used a
  game engine editor, you already know how to fly.
- **Larger-than-RAM clouds** — on first open, the file is streamed into an
  on-disk octree cache (built with bounded memory). While viewing, nodes are
  loaded asynchronously by screen-space priority within a RAM budget
  (auto-set from system memory, adjustable live) and evicted LRU.
  A 60M-point file indexes in ~4 seconds on Apple Silicon.
- **Full-density snapshots** — the realtime view is density-adaptive, but the
  snapshot button streams *every* point from disk through the GPU into an
  offscreen buffer (up to 4x the window resolution) and saves a PNG to
  `~/Pictures/Point Cloud Cruise/`. You get the full cloud in the image even when it
  never fit in RAM.
- **Formats**: PLY (ascii/binary), LAS, E57 (multi-scan, per-scan poses,
  spherical coordinates, color/intensity), PCD (ascii/binary/
  binary_compressed), XYZ/TXT/PTS/CSV. Clouds without color get a height
  gradient. (LAZ is not supported — convert to LAS first.)
- Double-precision handling for georeferenced coordinates (UTM etc.).

## Install

Grab the build for your OS from the
**[latest release](https://github.com/jirlock/point-cloud-cruise/releases/latest)**:

| OS | Download |
|---|---|
| **macOS** | [point-cloud-cruise-0.3.0.dmg](https://github.com/jirlock/point-cloud-cruise/releases/download/v0.3.0/point-cloud-cruise-0.3.0.dmg) |
| **Windows** (x64) | [point-cloud-cruise-0.3.0-windows-x64.zip](https://github.com/jirlock/point-cloud-cruise/releases/download/v0.3.0/point-cloud-cruise-0.3.0-windows-x64.zip) |
| **Linux** (x86_64) | [point-cloud-cruise-0.3.0-linux-x86_64.AppImage](https://github.com/jirlock/point-cloud-cruise/releases/download/v0.3.0/point-cloud-cruise-0.3.0-linux-x86_64.AppImage) |

**macOS** — open the DMG and drag Point Cloud Cruise.app into Applications. On
first launch, **right-click the app and choose "Open"** (the download is not
notarized by Apple yet; this is only needed once. If macOS still blocks it:
System Settings > Privacy & Security > "Open Anyway"). Universal binary — runs
natively on Apple Silicon and Intel.

**Windows** — unzip and run `pccruise.exe`. SmartScreen may warn on first run
(the build is unsigned); click "More info" > "Run anyway". No installer or
runtime needed — it's a self-contained executable.

**Linux** — `chmod +x point-cloud-cruise-*.AppImage` and run it. Uses your
system's OpenGL drivers; needs a desktop with OpenGL 4.1. To open files, drag
them onto the window (the native file dialog uses `zenity` if installed).

### Build from source

Requires CMake and a C++17 compiler. All dependencies (GLFW, Dear ImGui, stb,
libE57Format, Xerces-C) and a vendored glad GL loader are fetched/built and
statically linked automatically.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j8           # on Windows add: --config Release
./build/pccruise your-cloud.las   # or open/drag&drop a file in the app
```

- **macOS**: `brew install cmake`. Build the signed/notarized .app/DMG with `scripts/make_dmg.sh`.
- **Linux**: needs X11/GL dev headers, e.g. `sudo apt install build-essential cmake xorg-dev libgl1-mesa-dev`. Package an AppImage with `scripts/make_appimage.sh`.
- **Windows**: Visual Studio 2022 (MSVC) + CMake. The CRT is linked statically, so the resulting `pccruise.exe` is standalone.

## Controls

| Input | Action |
|---|---|
| RMB drag | Look around |
| W / A / S / D | Move forward / left / back / right |
| Q / E | Move down / up |
| Shift | Sprint (4x) |
| Scroll wheel | Adjust movement speed |
| F | Reset view (fit cloud) |
| P | Take snapshot |

## Headless snapshots

Render a full-density image from the command line (no window):

```sh
./build/pccruise data.e57 --snapshot out.png --size 3840x2160 \
    [--point-px 2] [--zup 1] [--cam x y z yaw pitch]
```

## Settings (UI panel)

- **RAM budget** — memory cap for loaded points
- **Detail (px)** — refinement threshold; lower = denser (more RAM/IO)
- **Point size** — point size multiplier
- **Z up** — data up-axis (LAS/E57/XYZ default to Z-up, PLY to Y-up)
- **Snapshot** — resolution multiplier (1x/2x/4x) and point pixel size

## Test data

```sh
python3 tools/gen_test_ply.py /tmp/test.ply 5000000   # terrain + torus + sphere
./build/gen_e57 /tmp/test.e57 3000000                 # 2 scans, one with a pose
./build/pccruise /tmp/test.ply
```

## How it works

```
src/io/       streaming readers (never load the whole file)
src/octree/   out-of-core octree builder (Potree-style partitioned storage,
              bottom-up grid subsampling) + runtime with async loader thread
src/render/   OpenGL renderer (LOD traversal, upload, LRU eviction) and
              the batched full-density snapshot path
src/app.cpp   GLFW + ImGui application
```

The cache lives in `~/.cache/pccruise/` (about 1x the source size) and is
validated against the source file's size/mtime, rebuilding automatically
when the source changes.

## License

[MIT](LICENSE). Uses [GLFW](https://www.glfw.org) (zlib),
[Dear ImGui](https://github.com/ocornut/imgui) (MIT),
[stb](https://github.com/nothings/stb) (MIT),
[libE57Format](https://github.com/asmaloney/libE57Format) (BSL-1.0),
and [Apache Xerces-C](https://xerces.apache.org/xerces-c/) (Apache-2.0).
